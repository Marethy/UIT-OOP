#pragma once
#include<iostream>
#include<string>
#include<string>
#include<algorithm>
#include<fstream>
#include<vector>
using namespace std;
class Quan
{
protected:
	string ma;
	string name;
	string loai;
	string mau;
public:
	string gioi_tinh;
	char size;
	double don_gia;
	void input();
	void output(ostream& os) const;
};

class QuanShort:public Quan
{
public:
	QuanShort()
	{
		loai = "Quan short";
	}
};
class QuanJean :public Quan
{
public:
	QuanJean()
	{
		loai = "Quan Jean";
	}
};
class QuanTay :public Quan
{
	int tieu_chuan;
public:
	QuanTay()
	{
		loai = "Quan tay";
	}
	void input();
	void output(ostream& os) const;
};