#include "Quan.h"

void Quan::input()
{
	cout << "Nhap ma: ";
	cin >> ma;
	cout << "Nhap mau: ";
	cin >> mau;
	cout << "Nhap gia: ";
	cin >> don_gia;
}

void Quan::output(ostream& os) const
{
	os << ma << " " << loai << " " << gioi_tinh << " " << size << " " << mau << " " << don_gia << " ";
}

void QuanTay::input()
{
	Quan::input();
	cout << "Nhap tieu chuan vai: (1,2)";
	cin >> tieu_chuan;
}

void QuanTay::output(ostream& os) const
{
	Quan::output(os);
	os << tieu_chuan;
}
