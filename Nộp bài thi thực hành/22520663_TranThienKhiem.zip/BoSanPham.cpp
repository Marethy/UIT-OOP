#include "BoSanPham.h"

void BoSanPham::input()
{
    cout << "Nhap ma bo: ";
    cin >> ma_bo;
    cout << "Nhap size bo: (S,M,L) ";
    cin >> size;

    cout << "Chon gioi tinh: (nam,nu) ";
    cin >> gioi_tinh;
    cout << "Nhap so phu kien can quan li: ";
    int n; cin >> n;
    for (int i = 0; i < n; i++)
    {
        cout << "Nhap phu kien thu" << i + 1 << ": ";
        cout << "Nhap loai phu kien: (1-Vongtay,2-KhanQuangCo ) ";
        PhuKien* p;
        int type; cin >> type;
        while (type < 1 or type>2)
        {
            cout << "Nhap lai: ";
            cin >> type;

        }
        cin.ignore();
        if (type == 1)
        {
            p = new VongTay;
            p->input();
        }
        else if (type == 2)
        {
            p = new Khan;
            p->input();
        }
        phukien.push_back(p);
    }
}

void BoSanPham::output(ostream& os) const
{
    os << "Bo quan ao: " << ma_bo << " " << loai_bo << " " << gioi_tinh << " " << size << " " << tong_gia() << endl;
}


void HoangHon::input()
{

    BoSanPham::input();
    ao->size = quan->size = this->size;
    ao->gioi_tinh = quan->gioi_tinh = this->gioi_tinh;
    cout << 123;
    cout << "Nhap ao so mi: ";
    ao->input();
    cout << "Nhap quan tay: ";
    quan->input();
}

void HoangHon::output(ostream& os) const
{
    BoSanPham::output(os);
    ao->output(os);
    quan->output(os);
}

double HoangHon::tong_gia() const
{
    double gia = ao->don_gia + quan->don_gia;
    for (int i = 0; i < phukien.size(); i++)
        gia += phukien[i]->gia();
    return gia * 1.3;
}

void BoFree::input()
{
    BoSanPham::input();
    ao->size = quan->size = this->size;
    ao->gioi_tinh = quan->gioi_tinh = this->gioi_tinh;
    cout << "Nhap ao thun: ";
    ao->input();
    cout << "Nhap quan: ";
    quan->input();
}

void BoFree::output(ostream& os) const
{
    BoSanPham::output(os);
    ao->output(os);
    quan->output(os);
}

double BoFree::tong_gia() const
{
    double gia = ao->don_gia + quan->don_gia;
    for (int i = 0; i < phukien.size(); i++)
        gia += phukien[i]->gia();
    return gia*1.2;
}
