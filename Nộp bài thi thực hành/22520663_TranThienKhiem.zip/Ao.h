#pragma once
#include<iostream>
#include<string>
#include<string>
#include<algorithm>
#include<fstream>
#include<vector>

using namespace std;

class Ao
{
protected:
	string ma;
	string name;
	string loai;
	string mau;
public:
	string gioi_tinh;
	char size;
	double don_gia;
	void input();
	void output(ostream& os) const;
};
class AoSoMi:public Ao
{
	int tieu_chuan;
public:
	AoSoMi()
	{
		loai = "Ao so mi";
	}
	void input();

	void output(ostream& os) const;
};
class AoThun :public Ao
{
public:
	AoThun()
	{
		loai = "Ao thun";
	}
};


