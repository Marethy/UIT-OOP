#include "QuanLi.h"

void QuanLi::input()
{
	cout << "Nhap so luong bo can quan li: ";
	int n;
	cin >> n;
	for (int i = 0; i < n; i++)
	{
		cout << "Thong tin bo thu " << i + 1 << ": ";
		cout << "Nhap bo: (1-HoangHon, 2-Free) ";
		int type;
		cin >> type;

		while (type < 1 or type>2)
		{
			cout << "Nhap lai: ";
			cin >> type;
		}
		BoSanPham* p;
		if (type == 1)
		{
			p = new HoangHon;
			p->input();
		}
		else if (type == 2)
		{
			p = new BoFree;
			p->input();
		}
	
		list.push_back(p);
	}
}

void QuanLi::output(ostream& os) const
{
	for (int i = 0; i < list.size(); i++)
	{
		list[i]->output(os);
		os << "\n*******************************************\n";
	}
}

QuanLi::~QuanLi()
{
	for (auto& it : list)
		delete it;
}
