#include"Ao.h"
#include"Quan.h"
#include"PhuKien.h"
#include"BoSanPham.h";
#pragma once
class QuanLi
{
public:
	vector<BoSanPham*> list;
	void input();
	void output(ostream& os) const;
	~QuanLi();
};

