#include "PhuKien.h"

void PhuKien::input()
{
    cout << "Nhap ma: ";
    cin >> ma;
    cout << "Nhap mau: ";
    cin >> mau;
    cout << "Nhap gia: ";
    cin >> don_gia;
}
double PhuKien::gia() const
{
    return don_gia;
}

void PhuKien::output(ostream& os) const
{
    os << ma << loai << " " << mau << " " << gia() << " ";
}


void VongTay::input()
{
    PhuKien::input();
    cout << "Nhap ban kinh: ";
    cin >> ban_kinh;

}

void VongTay::output(ostream& os) const
{
    PhuKien::output(os);
    os << ban_kinh;
}


void Khan::input()
{
    PhuKien::input();
    cout << "Nhap chieu dai: ";
    cin >> chieu_dai;
}

void Khan::output(ostream& os) const
{
    PhuKien::output(os);
    os << chieu_dai;
    
}
