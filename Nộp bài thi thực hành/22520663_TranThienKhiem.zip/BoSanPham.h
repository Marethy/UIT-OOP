#pragma once
#include"Ao.h"
#include"Quan.h"
#include"PhuKien.h"

#include<iostream>
#include<string>
#include<string>
#include<algorithm>
#include<fstream>
#include<vector>
using namespace std;
class BoSanPham
{
protected:
	string ma_bo;
	string loai_bo;
	char size;
	string gioi_tinh;

	vector<PhuKien*> phukien;
public:
	virtual void input();
	virtual void output(ostream& os) const;
	virtual double tong_gia() const = 0;
};

class HoangHon:public BoSanPham
{
protected:
	AoSoMi* ao;
	QuanTay* quan;
public:
	HoangHon()
	{
		loai_bo = "Hoang Hon";
		ao = new AoSoMi;
		quan = new QuanTay;
	}
	void input();
	void output(ostream& os) const;
	double tong_gia() const;
	
};
class BoFree:public BoSanPham
{
protected:
	AoThun* ao;
	Quan* quan;
public:
	BoFree()
	{
		loai_bo = "Bo Free";
		ao = new AoThun;
		quan = new Quan;
	}
	void input();
	void output(ostream& os) const;
	double tong_gia() const;
};


