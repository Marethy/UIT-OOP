#include "Ao.h"

void Ao::input()
{
	cout << "Nhap ma: ";
	cin >> ma;
	cout << "Nhap mau: ";
	cin >> mau;
	cout << "Nhap gia: ";
	cin >> don_gia;
}

void Ao::output(ostream& os) const
{
	os << ma << " " << loai << " " << gioi_tinh << " " << size << " " << mau << " " << don_gia << " ";
}


void AoSoMi::input()
{
	Ao::input();
	cout << "Nhap tieu chuan vai : (1,2) ";
	cin >> tieu_chuan;
}

void AoSoMi::output(ostream& os) const
{
	Ao::output(os);
	os << tieu_chuan;
}


	