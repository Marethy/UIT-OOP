#include"Ao.h"
#include"Quan.h"
#include"PhuKien.h"
#include"BoSanPham.h";
#include"QuanLi.h"
int main()
{
	ofstream  fOut("danh_sach_bo_quan_ao.txt");
	QuanLi ql;
	ql.input();
	ql.output(cout);
	ql.output(fOut);
	fOut.close();
	return 0;

}