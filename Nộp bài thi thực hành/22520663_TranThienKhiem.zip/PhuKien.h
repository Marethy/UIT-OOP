#pragma once
#include<iostream>
#include<string>
#include<string>
#include<algorithm>
#include<fstream>
#include<vector>
using namespace std;
class PhuKien
{
protected:
	string ma;
	string loai;
	string mau;
	double don_gia;
public:
	virtual void input();
	virtual  void output(ostream& os) const;
	double gia() const;
};

class VongTay :public PhuKien
{
protected:
	double ban_kinh;
public:
	VongTay()
	{
		loai = "Vong tay";
	}
	void input();
	void output(ostream& os) const;
};
class Khan :public PhuKien
{
protected:
	double chieu_dai;
public:
	Khan()
	{
		loai = "Khan quang co";
	}
	void input();
	void output(ostream& os) const;

};


