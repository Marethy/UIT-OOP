#include "Monster.h"

void Monster:: input() 
{
    GameObject::input();
    cout << "Nhap ngu hanh (1-KIM, 2-THUY, 3-MOC, 4-HOA, 5-THO): ";
    int el;
    cin >> el;
    element = static_cast<Elements>(el);
    cout << "Nhap loai cua quai vat: ";
    int fac;
    cin >> fac;
    faction = static_cast<FactionOfMonster>(fac);
}

void Monster::output() const 
{
    GameObject::output();
    cout << "Phe cua quai vat: ";
    switch (faction) {
    case NORMAL:
        cout << "THONG_THUONG";
        break;
    case BOSS:
        cout << "DAU_LINH";
        break;
    }
    cout << endl;
}

int Monster::baseDamage() const 
{
    if (faction == NORMAL)
        return level * 3;
    else if (faction == BOSS)
        return level * 7;
}

double Monster::realDamage(const GameObject& obj) const 
{
    double damage = baseDamage() * (1 + sinhKhac(obj));
    return damage;
}