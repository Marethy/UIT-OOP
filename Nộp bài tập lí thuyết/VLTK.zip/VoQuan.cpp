#include "VoQuan.h"

VoQuan::~VoQuan()
{
	for (int i = 0; i < size; i++)
		delete list[i];
	delete[] list;
}

void VoQuan ::input() 
{
    cout << "Phai cua nguoi choi: " << endl;
    cout << "(1-THIEU_LAM, 2-THIEN_VUONG_BANG, 3-NGU_DOC_GIAO, 4-DUONG_MON,5-NGA_MY, " << endl;
    cout << "6-THUY_YEN_MON, 7-CAI_BANG, 8-THIEN_NHAN_GIAO, 9-CON_LON, 10-VO_DANG)" << endl;
    cout << "Loai quai vat: " << endl;
    cout << "(1 - THONG_THUONG, 2 - DAU_LINH)" << endl;
    cout << "Nhap so luong doi tuong: ";
    cin >> size;
    list = new GameObject * [size];
    for (int i = 0; i < size; i++) 
    {
        int type;
        cout << "Nhap loai doi tuong (1-Nguoi choi, 2-Quai vat): ";
        cin >> type;
        if (type == 1)
            list[i] = new Player();
        else if (type == 2)
            list[i] = new Monster();
        else {
            cout << "Loai doi tuong khong hop le." << endl;
            continue;
        }

        cout << "Nhap thong tin cho doi tuong " << i + 1 << ":" << endl;
        list[i]->input();
    }
}


void VoQuan::output() const
{
    for (int i = 0; i < size; i++)
    {
        cout << "Thong tin doi tuong " << i + 1 << ":" << endl;
        list[i]->output();
        cout << endl;
    };

}

GameObject* VoQuan::maxDamage() const 
{
    if (size == 0)
        return nullptr;

    GameObject* maxObj = list[0];
    for (int i = 1; i < size; i++) {
        if (list[i]->baseDamage() > maxObj->baseDamage()) 
            maxObj = list[i];
    }
    return maxObj;
}

bool VoQuan::compare(const GameObject& a, const GameObject& b)
{
    double damageA = a.realDamage(b);
    double damageB = b.realDamage(a);

    cout << "Sat thuong tac dong A len B: " << damageA << endl;
    cout << "Sat thuong tac dong B len A: " << damageB << endl;

    if (damageA > damageB)
        cout << "A tac dong manh hon B" << endl;
    else if (damageA < damageB)
        cout << "B tac dong manh hon A" << endl;
    else
        cout << "A va B tac dong bang nhau" << endl;
    return (damageA > damageB);
}
void VoQuan::compareObject(int index1, int index2)
{
    GameObject* obj1 = list[index1];
    GameObject* obj2 = list[index2];
    compare(*obj1, *obj2);

}