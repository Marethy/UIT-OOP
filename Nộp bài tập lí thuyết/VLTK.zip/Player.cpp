#include"Player.h"

void Player::input()
{
	GameObject::input();
	cout << "Nhap mon phai cua nguoi choi: ";
	int fac;
	cin >> fac;
	faction = static_cast<FactionOfPlayer>(fac);
    switch (fac)
    {
    case 1:
    case 2:
        element = static_cast<Elements> (1);
        break;
    case 3:
    case 4:
        element = static_cast<Elements> (2);
        break;
    case 5:
    case 6:
        element = static_cast<Elements>(3);
        break;
    case 7:
    case 8:
        element = static_cast<Elements>(4);
        break;
    case 9:
    case 10:
        element = static_cast<Elements> (5);
        break;
    }
}
void Player::output() const
{
    GameObject::output();
    cout << "Phe cua nguoi choi: ";
    switch (faction) 
    {
    case THIEU_LAM:
        cout << "THIEU_LAM";
        break;
    case THIEN_VUONG_BANG:
        cout << "THIEN_VUONG_BANG";
        break;
    case NGU_DOC_GIAO:
        cout << "NGU_DOC_GIAO";
        break;
    case DUONG_MON:
        cout << "DUONG_MON";
        break;
    case NGA_MY:
        cout << "NGA_MY";
        break;
    case THUY_YEN_MON:
        cout << "THUY_YEN_MON";
        break;
    case CAI_BANG:
        cout << "CAI_BANG";
        break;
    case THIEN_NHAN_GIAO:
        cout << "THIEN_NHAN_GIAO";
        break;
    case CON_LON:
        cout << "CON_LON";
        break;
    case VO_DANG:
        cout << "VO_DANG";
        break;
    }
    cout << endl;
}
int Player::baseDamage() const 
{
	return level * 5;
}

double Player::realDamage(const GameObject& obj) const 
{
	double damage = baseDamage() * (1 + sinhKhac(obj));
	return damage;
}

