#pragma once
#include"GameObject.h"
class Player : public GameObject
{
private:
	FactionOfPlayer faction;
public:
	void input();
	void output() const;
	int baseDamage() const;
	double realDamage(const GameObject& sv) const;

};
