#pragma once
#include"GameObject.h"
#include"Player.h"
#include"Monster.h"
class VoQuan
{
private:
	int size;
	GameObject** list;

public:
	VoQuan() :size(size), list(list) {};
	~VoQuan();
	void input();
	void output() const;
	GameObject* maxDamage() const;
	bool compare(const GameObject& obj1, const GameObject& object2);
	void compareObject(int index1, int index2);
};



