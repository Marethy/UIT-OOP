#pragma once
#include<iostream>
#include<string>
using namespace std;
enum Elements { KIM = 1, THUY, MOC, HOA, THO };
enum FactionOfPlayer { THIEU_LAM = 1, THIEN_VUONG_BANG, NGU_DOC_GIAO, DUONG_MON, NGA_MY, THUY_YEN_MON, CAI_BANG, THIEN_NHAN_GIAO, CON_LON, VO_DANG };
enum FactionOfMonster { NORMAL = 1, BOSS };
class GameObject
{
protected:
	string name;
	Elements element;
	int level;
public:
	virtual void input();
	virtual void output() const;
	virtual int baseDamage() const = 0;
	virtual double realDamage(const GameObject& obj) const = 0;
	double sinhKhac (const GameObject& obj) const;
};

