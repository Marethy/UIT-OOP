#include "GameObject.h"

void GameObject::input()
{
    cout << "Nhap ten: ";
    cin.ignore();
    getline(cin, name);
    cout << "Nhap cap do: ";
    cin >> level;
}

void GameObject::output() const
{
    cout << "Ten: " << name << endl;
    cout << "Ngu hanh: ";
    switch (element) {
    case KIM:
        cout << "KIM";
        break;
    case THUY:
        cout << "THUY";
        break;
    case MOC:
        cout << "MOC";
        break;
    case HOA:
        cout << "HOA";
        break;
    case THO:
        cout << "THO";
        break;
    }
    cout << endl;
    cout << "Cap do: " << level << endl;
}


double GameObject::sinhKhac(const GameObject& obj) const
{
    if ((element == KIM and obj.element == THUY) or (element == THUY and obj.element == MOC) or (element == MOC and obj.element == HOA)
        or (element == HOA and obj.element == THO) or (element == THO and obj.element == KIM))
        return 0.1;
    if ((element == KIM and obj.element == MOC) or (element == THUY and obj.element == HOA) or (element == MOC and obj.element == THO)
        or (element == HOA and obj.element == KIM) or (element == THO and obj.element == THUY))
        return 0.2;
    if ((element == MOC and obj.element == KIM) or (element == HOA and obj.element == THUY) or (element == THO and obj.element == MOC)
        or (element == KIM and obj.element == HOA) or (element == THUY and obj.element == THO))
        return -0.2;
    return 0;
}
