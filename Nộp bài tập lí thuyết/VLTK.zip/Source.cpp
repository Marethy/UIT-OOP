#include"GameObject.h"
#include"Player.h"
#include"Monster.h"
#include"VoQuan.h"

int main()
{
	VoQuan vq;
	vq.input();
	vq.compareObject(0, 1);
	cout << "\n\n";
	vq.maxDamage()->output();
	cout << "\n\n";
	vq.output();
	return 0;
}
