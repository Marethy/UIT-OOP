#pragma once
#include"GameObject.h"
class Monster:public GameObject
{
private:
	FactionOfMonster faction;
public:
	void input();
	void output() const;
	int baseDamage() const;
	double realDamage(const GameObject& sv) const;

};

