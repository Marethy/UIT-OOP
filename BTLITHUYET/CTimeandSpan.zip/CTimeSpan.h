#pragma once
#include<iostream>
using namespace std;

class CTimeSpan {
private:
    int second;  
public:
    CTimeSpan(int second = 0) : second(second) {};
    friend CTimeSpan operator+(const CTimeSpan& t1, const CTimeSpan& t2);
    friend CTimeSpan operator-(const CTimeSpan& t1, const CTimeSpan& t2);
    friend  bool operator==(const CTimeSpan& t1, const CTimeSpan& t2);
    friend bool operator !=(const CTimeSpan& t1, const CTimeSpan& t2);
    friend bool operator>(const CTimeSpan& t1, const CTimeSpan& t2);
    friend bool operator>=(const CTimeSpan& t1, const CTimeSpan& t2);
    friend bool operator<(const CTimeSpan& t1, const CTimeSpan& t2);
    friend bool operator<=(const CTimeSpan& t1, const CTimeSpan& t2);
};




