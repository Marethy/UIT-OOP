#include"CTimeSpan.h"

CTimeSpan operator+(const CTimeSpan& t1, const CTimeSpan& t2)
{
    int ans = t1.second + t2.second;
    return CTimeSpan(ans);
}

CTimeSpan operator-(const CTimeSpan& t1, const CTimeSpan& t2)
{
    int ans = t1.second - t2.second;
    return CTimeSpan(ans);
}

bool operator==(const CTimeSpan& t1, const CTimeSpan& t2)
{
    return t1.second == t2.second;
}

bool operator!=(const CTimeSpan& t1, const CTimeSpan& t2)
{
    return t1.second != t2.second;
}

bool operator>(const CTimeSpan& t1, const CTimeSpan& t2)
{
    return t1.second > t2.second;
}

//bool operator>(const CTimeSpan& t1, const CTimeSpan& t2)
//{
//    return t1.second > t2.second;
//}

bool operator>=(const CTimeSpan& t1, const CTimeSpan& t2)
{
    return t1.second >= t2.second;
}

bool operator<(const CTimeSpan& t1, const CTimeSpan& t2)
{
    return t1.second < t2.second;
}

bool operator<=(const CTimeSpan& t1, const CTimeSpan& t2)
{
    return t1.second <= t2.second;
}