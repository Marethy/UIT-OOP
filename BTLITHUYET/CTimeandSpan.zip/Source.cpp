#include"CTime.h"
#include"CTimeSpan.h"

int main()
{
	CTime t;
	cin >> t;
	CTime t2;
	t2=--t + 5;
	CTimeSpan t3=t - t2++;
	cout << t2;

}