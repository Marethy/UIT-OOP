#include "CTime.h"
#include "CTimeSpan.h"

CTime operator+(CTime& ct, int sec)
{
	int sum_sec = ct.hours * 3600 + ct.minutes * 60 + ct.seconds + sec;
	int new_hours = sum_sec /3600;
	int new_minutes = (sum_sec / 60) % 60;
	int new_seconds = sum_sec %60;
	CTime result(new_hours, new_minutes, new_seconds);
	return result;
}

CTime operator-(CTime& ct, int sec)
{
	int sum_sec = ct.hours * 3600 + ct.minutes * 60 + ct.seconds - sec;
	int new_hours = sum_sec / 3600;
	int new_minutes = (sum_sec / 60) % 60;
	int new_seconds = sum_sec % 60;
	CTime result(new_hours, new_minutes, new_seconds);
	return result;
}


CTimeSpan operator-(const CTime& ct1, const CTime& ct2)
{
	int sum_second1 = ct1.hours * 3600 + ct1.minutes * 60 + ct1.seconds;
	int sum_second2 = ct2.hours * 3600 + ct2.minutes * 60 + ct2.seconds;
	CTimeSpan result(sum_second1 - sum_second2);
	return result;
}
CTime& operator++(CTime& ct)
{
	ct=ct + 1;
	return ct;
}
CTime operator++(CTime& ct, int)
{
	CTime temp(ct);
	ct=ct + 1;
	return temp;
}
CTime& operator--(CTime& ct)
{
	ct=ct - 1;
	return ct;
}

CTime operator--(CTime& ct, int)
{
	CTime temp(ct);
	ct=ct-1;
	return temp;
}


ostream& operator<<(ostream& cout, CTime& ct)
{
	cout << ct.hours << "h " << ct.minutes << "m " << ct.seconds << "s ";
	return cout;
}
istream& operator>>(istream& cin, CTime& ct)
{
	cin >> ct.hours >> ct.minutes >> ct.seconds;
	return cin;
}