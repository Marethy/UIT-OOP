#pragma once	
#include"CTimeSpan.h"
class CTime
{
private:
	int hours;
	int minutes;
	int seconds;
public:
	CTime(int hours = 0, int minutes = 0, int seconds = 0) : hours(hours), minutes(minutes), seconds(seconds) {};
	friend CTime operator + (CTime&, int sec);
	friend CTime operator -(CTime&, int sec);
	friend CTimeSpan operator - (const CTime& , const CTime&);

	friend CTime& operator ++(CTime&);
	friend CTime operator ++(CTime&, int);
	friend CTime& operator --(CTime&);
	friend CTime operator --(CTime&, int);
	friend istream& operator >> (istream&, CTime&);
	friend ostream& operator<<(ostream&, CTime&);


};

