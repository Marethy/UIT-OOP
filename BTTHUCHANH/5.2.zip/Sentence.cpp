#include "Sentence.h"

void Sentence::addWord(const Word& w)
{
	words.push_back(w);
}

int Sentence::getWordCount() const
{
	return (int)words.size();
}

bool cmp(const Word& w1, const Word& w2)
{
	string word1 = w1.getWord();
	string word2 = w2.getWord();
	if (word1[0] >= 'A' and word1[0] <= 'Z') word1[0] += 32;
	if (word2[0] >= 'A' and word2[0] <= 'Z') word2[0] += 32;
	return word1 < word2;
}
void Sentence::sortWords()
{
	sort(words.begin(), words.end(), cmp);
}

const vector<Word>& Sentence::getWords() const
{
	return words;
}
