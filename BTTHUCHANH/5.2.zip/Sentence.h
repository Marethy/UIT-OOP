#pragma once
#include"Word.h"
class Sentence 
{
private:
    vector<Word> words;

public:
    Sentence() {}
    void addWord(const Word& w);
    int getWordCount() const;
    void sortWords();
    const vector<Word>& getWords() const;
    friend bool cmp(const Word&, const Word&);
};

