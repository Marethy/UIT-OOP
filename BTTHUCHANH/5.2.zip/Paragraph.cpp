#include "Paragraph.h"

void Paragraph::addSentence(const Sentence& s)
{
	sentences.push_back(s);
}

int Paragraph::getSentenceCount() const
{
	return (int)sentences.size();
}

int Paragraph::getWordCount() const
{
	int count = 0;
	for (const auto& sentence : sentences)
		count += sentence.getWordCount();
	return count;
}

vector<string> Paragraph::findMostFrequentWords() const
{
	map<string, int> wordFrequency;
	for (const auto& sentence : sentences)
		for (const auto& word : sentence.getWords())
			wordFrequency[word.getWord()]++;
	int maxFrequency = 0;
	for (const auto& pair : wordFrequency)
		if (maxFrequency < pair.second) maxFrequency = pair.second;
	vector<string> mostFreqWords;
	for (const auto& pair : wordFrequency)
		if (maxFrequency == pair.second)
			mostFreqWords.push_back(pair.first);
	return mostFreqWords;
}
void Paragraph::sortWordsInSentences()
{
	for (auto& sentence : sentences) 
		sentence.sortWords();
}

const vector<Sentence>& Paragraph::getSentences()
{
	return sentences;
}
