#pragma once
#include"Word.h"
#include"Sentence.h"
class Paragraph 
{
private:
    vector<Sentence> sentences;

public:
    Paragraph() {}
    void addSentence(const Sentence& s);
    int getSentenceCount() const;
    int getWordCount() const;
    vector<string> findMostFrequentWords() const;
    void sortWordsInSentences();
    const vector<Sentence>& getSentences();

};