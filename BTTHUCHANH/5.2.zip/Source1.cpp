﻿#include"Word.h"
#include"Sentence.h"
#include"Paragraph.h"

int main()
{
    ifstream inputFile("input.txt");
    ofstream outputFile("output.txt");
    Paragraph paragraph;
    string line;
    int i = 0;
    // nhập
    while (getline(inputFile, line))
    {
        Sentence sentence;
        string word;
        for (char c : line)
        {
            if (c != ' ' && c != '.' && c != ',' && c != '?' && c != '!')
                word += c;
            else if (!word.empty())
            {
                sentence.addWord(Word(word));
                word = "";
            }
        }
        if (!word.empty())
        {
            sentence.addWord(Word(word));
            word = "";
        }
        paragraph.addSentence(sentence);

    }
    //đếm câu
    int sentenceCount = paragraph.getSentenceCount();
    // đém từ trong câu
    vector<int> wordCounts;
    for (const auto& sentence : paragraph.getSentences())
        wordCounts.push_back(sentence.getWordCount());

    // từ xuất hiện nhiều nhất
    vector<string> mostFrequentWords = paragraph.findMostFrequentWords();

    // sắp xếp từ trong mỗi câu
    paragraph.sortWordsInSentences();

    //xuất
    outputFile << "Numbers of sentences: " << sentenceCount << endl;
    outputFile << "Numbers of words in each sentence:" << endl;
    for (int i = 0; i < sentenceCount; i++) {
        outputFile << "Sentence " << i + 1 << ": " << wordCounts[i] << " words" << endl;
    }
    outputFile << endl;

    outputFile << "Most frequent words:" << endl;
    for (const auto& word : mostFrequentWords)  
        outputFile << word << endl;
    outputFile << endl;

    outputFile << "Sorted words in each sentence:" << endl;
    for (const auto& sentence : paragraph.getSentences()) {
        for (const auto& word : sentence.getWords()) 
            outputFile << word.getWord() << " ";
        outputFile << endl;
    }

    inputFile.close();
    outputFile.close();
    return 0;
}
