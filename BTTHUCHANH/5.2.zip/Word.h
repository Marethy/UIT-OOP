#pragma once
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <map>
#include <algorithm>
#include<string>
using namespace std;
class Word 
{
private:
    string word;

public:
    Word(string word) : word(word) {}
    string getWord() const 
    {
        return word;
    }
};

